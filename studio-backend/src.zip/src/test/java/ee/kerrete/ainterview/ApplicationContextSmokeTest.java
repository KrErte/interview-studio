package ee.kerrete.ainterview;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationContextSmokeTest {

    @Test
    void contextLoads() {
        // verifies Spring context starts with unique bean names
    }
}

