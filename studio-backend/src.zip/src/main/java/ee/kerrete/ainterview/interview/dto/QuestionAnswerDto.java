package ee.kerrete.ainterview.interview.dto;

/**
 * Legacy DTO kept for backward compatibility; no longer used by the LITE flow.
 */
public record QuestionAnswerDto(String question, String answer) {
}

