package ee.kerrete.ainterview.dejavu.dto;

import java.util.List;

public record DejaVuPredictionResponse(List<String> predictedQuestions) {
}

