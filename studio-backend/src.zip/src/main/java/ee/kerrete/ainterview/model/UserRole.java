package ee.kerrete.ainterview.model;

public enum UserRole {
    CANDIDATE,
    USER,
    ADMIN,
    JOBSEEKER,
    INTERVIEWER,
    ORG_ADMIN
    // kui tahad hiljem lisada:
    // INTERVIEWER,
    // OTHER_ROLES...
}
