package ee.kerrete.ainterview.interview.enums;

public enum InterviewerStyle {
    HR,
    TECH,
    TEAM_LEAD,
    MIXED
}

