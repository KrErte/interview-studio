package ee.kerrete.ainterview.softskills.enums;

/**
 * Source/perspective for a soft-skill evaluation.
 */
public enum SoftSkillSource {

    HR,
    TECH_LEAD,
    TEAM_LEAD,
    AI_MERGED
}


