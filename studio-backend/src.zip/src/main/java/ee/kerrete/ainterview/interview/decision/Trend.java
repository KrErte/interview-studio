package ee.kerrete.ainterview.interview.decision;

public enum Trend {
    IMPROVING,
    DECLINING,
    FLAT,
    MIXED,
    UNDEFINED
}

