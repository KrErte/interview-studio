package ee.kerrete.ainterview.skillmatrix.enums;

public enum SessionStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}

