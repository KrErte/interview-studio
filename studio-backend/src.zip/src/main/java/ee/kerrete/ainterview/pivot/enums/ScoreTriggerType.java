package ee.kerrete.ainterview.pivot.enums;

public enum ScoreTriggerType {
    ROLE_MATCH_COMPUTE,
    PROFILE_UPDATE,
    MANUAL_REFRESH
}

