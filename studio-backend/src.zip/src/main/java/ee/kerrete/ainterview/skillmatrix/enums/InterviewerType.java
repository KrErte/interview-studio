package ee.kerrete.ainterview.skillmatrix.enums;

public enum InterviewerType {
    HR,
    TECH_EXPERT,
    TEAM_LEAD
}

