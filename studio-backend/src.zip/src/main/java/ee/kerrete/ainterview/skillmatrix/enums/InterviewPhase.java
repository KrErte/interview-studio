package ee.kerrete.ainterview.skillmatrix.enums;

public enum InterviewPhase {
    HR,
    TECHNICAL,
    TEAM_FIT,
    EVALUATION
}

