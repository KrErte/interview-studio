package ee.kerrete.ainterview.career.model;

public enum MarketplaceVisibility {
    PUBLIC,
    LIMITED,
    OFF
}

