package ee.kerrete.ainterview.interview.decision;

public enum InterviewerStyle {
    HR,
    TECH,
    TEAM_LEAD
}

