package ee.kerrete.ainterview.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JobMatchRequest {
    private String email;
    private String targetRole;
    private String jobDescription;
    private String cvText;
}













