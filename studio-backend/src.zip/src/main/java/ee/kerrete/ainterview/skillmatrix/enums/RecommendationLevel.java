package ee.kerrete.ainterview.skillmatrix.enums;

public enum RecommendationLevel {
    STRONG_HIRE,
    HIRE,
    NEUTRAL,
    NO_HIRE
}

