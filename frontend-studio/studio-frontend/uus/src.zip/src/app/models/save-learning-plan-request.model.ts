export interface SaveLearningPlanRequest {
  email: string;
  jobTitle: string;
  missingSkills: string[];
  roadmap: string[];
}
