export const environment = {
  production: true,
  apiUrl: 'https://YOUR_DOMAIN',
  // apiBaseUrl retained for existing services; points to same API gateway root
  apiBaseUrl: 'https://YOUR_DOMAIN'
};
