export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8080',
  // Aliased for legacy consumers
  apiUrl: 'http://localhost:8080'
};
